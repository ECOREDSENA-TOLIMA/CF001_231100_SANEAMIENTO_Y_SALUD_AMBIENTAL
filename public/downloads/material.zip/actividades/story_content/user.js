function ExecuteScript(strId)
{
  switch (strId)
  {
      case "5Yehayy2l7Q":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

